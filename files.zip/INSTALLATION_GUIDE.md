# 🚀 GUIDE D'INSTALLATION RAPIDE - AfricaScoutPro

## Prérequis

Avant de commencer, assurez-vous d'avoir :
- **Node.js 18+** installé ([Télécharger](https://nodejs.org/))
- **npm** ou **yarn** (inclus avec Node.js)
- Un éditeur de code (VS Code recommandé)

---

## Installation en 3 Étapes

### 1️⃣ Installer les Dépendances

Ouvrez un terminal dans le dossier `africascoutpro/` et exécutez :

```bash
npm install
```

Cela installera automatiquement :
- Next.js 15
- React 18
- TypeScript
- TailwindCSS
- Lucide React (icons)
- Et toutes les autres dépendances

⏱️ **Durée estimée :** 1-2 minutes

---

### 2️⃣ Lancer le Serveur de Développement

```bash
npm run dev
```

Vous verrez dans le terminal :

```
  ▲ Next.js 15.1.6
  - Local:        http://localhost:3000
  - Network:      http://192.168.x.x:3000

 ✓ Ready in 2.1s
```

---

### 3️⃣ Ouvrir dans le Navigateur

Ouvrez votre navigateur à l'adresse :

```
http://localhost:3000
```

🎉 **C'est tout ! L'application devrait se charger.**

---

## 🗺️ Navigation Rapide

Une fois l'app lancée, visitez :

| Page | URL | Description |
|------|-----|-------------|
| **Landing** | `/` | Page d'accueil avec hero + features |
| **Joueurs** | `/players` | Liste de tous les joueurs + filtres |
| **Profil Joueur** | `/players/amadou-diallo` | Exemple de profil détaillé |
| **Quiz** | `/quiz` | Test de QI Footballistique |
| **Dashboard** | `/dashboard` | Mode démo (Joueur/Recruteur) |

---

## 🔧 Commandes Utiles

### Développement
```bash
npm run dev      # Lance le serveur de dev (hot reload)
```

### Production
```bash
npm run build    # Compile l'application
npm start        # Lance la version compilée
```

### Linting
```bash
npm run lint     # Vérifie le code (ESLint)
```

---

## 🐛 Dépannage

### Erreur : "Module not found"
**Solution :** Relancez `npm install`

### Port 3000 déjà utilisé
**Solution :** Changez le port :
```bash
PORT=3001 npm run dev
```

### Erreur TypeScript
**Solution :** Vérifiez que TypeScript est installé :
```bash
npm install typescript --save-dev
```

---

## 📁 Structure à Connaître

```
africascoutpro/
├── app/              # Pages Next.js (App Router)
│   ├── page.tsx      # Landing page
│   ├── players/      # Routes /players
│   ├── quiz/         # Route /quiz
│   └── dashboard/    # Route /dashboard
├── components/       # Composants réutilisables
│   ├── Header.tsx
│   ├── Footer.tsx
│   ├── PlayerCard.tsx
│   └── ui/           # Composants UI de base
├── lib/              # Utilitaires + données
│   ├── types.ts      # Types TypeScript
│   ├── data.ts       # Joueurs fictifs + quiz
│   └── utils.ts      # Fonctions helper
└── public/           # Assets statiques
```

---

## 🎨 Personnalisation Rapide

### Changer les Couleurs

Éditez `tailwind.config.ts` :

```typescript
colors: {
  primary: {
    500: '#3B82F6',  // Changez cette valeur
  },
  accent: {
    gold: '#F59E0B',  // Changez cette valeur
  },
}
```

### Ajouter des Joueurs

Éditez `lib/data.ts` dans `mockPlayers[]` :

```typescript
{
  id: '13',
  slug: 'nouveau-joueur',
  firstName: 'Nouveau',
  lastName: 'Joueur',
  // ... autres infos
}
```

---

## 🚀 Déploiement (Optionnel)

### Vercel (Recommandé)

1. Push le code sur GitHub
2. Allez sur [vercel.com](https://vercel.com)
3. Import GitHub repo
4. Deploy automatique !

### Build Local

```bash
npm run build
npm start
```

L'app sera accessible sur `http://localhost:3000` en mode production.

---

## 📚 Ressources

- **Documentation Next.js :** [nextjs.org/docs](https://nextjs.org/docs)
- **Tailwind CSS :** [tailwindcss.com/docs](https://tailwindcss.com/docs)
- **TypeScript :** [typescriptlang.org](https://www.typescriptlang.org/)

---

## ❓ Besoin d'Aide ?

1. Consultez le `README.md` pour plus de détails
2. Vérifiez la console du navigateur (F12) pour les erreurs
3. Relisez le terminal pour les logs Next.js

---

**✅ Prêt à coder ! Bon développement !** 🚀
