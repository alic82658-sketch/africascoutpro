# AfricaScoutPro

![AfricaScoutPro](https://img.shields.io/badge/Status-MVP-green)
![Next.js](https://img.shields.io/badge/Next.js-15.1-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)
![TailwindCSS](https://img.shields.io/badge/TailwindCSS-3.4-38bdf8)

**AfricaScoutPro** est une plateforme SaaS qui connecte les jeunes talents footballistiques africains avec des recruteurs professionnels, en s'appuyant sur le mérite, la transparence et un Test de QI Footballistique innovant.

---

## 🎯 Vision Produit

Donner de l'espoir et une vraie opportunité à des milliers de jeunes joueurs africains n'ayant pas de visibilité. Le ton est sérieux, premium, inspirant, sans promesses mensongères, et orienté "mérite + travail + preuves".

---

## ✨ Fonctionnalités MVP

### Pour les Joueurs
- ✅ Création de profil complet (infos personnelles, stats, vidéo)
- ✅ Génération automatique d'une **Player Card style FIFA** (avec rareté bronze/silver/gold/elite)
- ✅ **Test de QI Footballistique** (10 questions scénarisées)
- ✅ Score et profil tactique affichés sur la carte
- ✅ Page profil public partageable

### Pour les Recruteurs
- ✅ Exploration de tous les joueurs (grille de cartes)
- ✅ Filtres avancés (poste, pays, âge, pied, score QI)
- ✅ Recherche par nom/ville
- ✅ Système de favoris (localStorage)
- ✅ Page joueur détaillée avec bouton contact

### Général
- ✅ Landing page conversion optimisée
- ✅ Mode démo (toggle Joueur/Recruteur)
- ✅ 12 joueurs fictifs pré-chargés
- ✅ 100% responsive (mobile-first)
- ✅ Design system premium

---

## 🚀 Installation & Lancement

### Prérequis
- Node.js 18+ 
- npm ou yarn

### Installation

```bash
# 1. Cloner ou télécharger le projet
cd africascoutpro

# 2. Installer les dépendances
npm install

# 3. Lancer en développement
npm run dev

# 4. Ouvrir dans le navigateur
# http://localhost:3000
```

### Build Production

```bash
npm run build
npm start
```

---

## 📁 Structure du Projet

```
africascoutpro/
├── app/
│   ├── layout.tsx              # Layout racine + fonts
│   ├── page.tsx                # Landing page
│   ├── globals.css             # Styles globaux
│   ├── players/
│   │   ├── page.tsx            # Liste joueurs + filtres
│   │   └── [slug]/
│   │       └── page.tsx        # Profil joueur détaillé
│   ├── quiz/
│   │   └── page.tsx            # Test QI Footballistique
│   └── dashboard/
│       └── page.tsx            # Dashboard mode démo
├── components/
│   ├── Header.tsx              # Navigation sticky
│   ├── Footer.tsx              # Footer
│   ├── PlayerCard.tsx          # Carte joueur FIFA-like
│   └── ui/
│       ├── button.tsx          # Composant Button
│       └── input.tsx           # Composant Input
├── lib/
│   ├── types.ts                # Types TypeScript
│   ├── utils.ts                # Utilitaires (cn, rarity, etc.)
│   └── data.ts                 # Données fictives + quiz
├── public/                     # Assets statiques
├── tailwind.config.ts          # Configuration Tailwind
├── tsconfig.json               # Configuration TypeScript
└── package.json                # Dépendances
```

---

## 🎨 Design System

### Palette de Couleurs

```css
/* Primary - Prestige & Sport */
--primary-900: #0A0E27  /* Bleu nuit profond */
--primary-500: #3B82F6  /* Bleu accent vif */

/* Accent - Or/Excellence */
--accent-gold: #F59E0B   /* Or */
--accent-silver: #94A3B8 /* Argent */
--accent-bronze: #D97706 /* Bronze */

/* Neutrals */
--neutral-950: #020617  /* Noir pur */
--neutral-50: #F8FAFC   /* Blanc cassé */
```

### Typographie

- **Headings :** DM Sans (Google Fonts)
- **Body :** Inter (Google Fonts)

---

## 🧠 Test de QI Footballistique

### Concept

Le quiz évalue la compréhension tactique à travers 10 situations réelles de jeu :
- Lecture de jeu
- Placement
- Pressing
- Transitions
- Gestion de match

### Scoring

- **Score :** 0-100 (moyenne des points obtenus)
- **Rareté :**
  - Bronze : 50-69
  - Silver : 70-84
  - Gold : 85-94
  - Elite : 95-100
- **Profil tactique :** Déterminé par les réponses dominantes (Playmaker, Ball Winner, Finisseur, etc.)

**Important :** Le test est un indicateur complémentaire, pas une vérité absolue. Il aide les recruteurs à avoir une vision plus complète du profil.

---

## 🔧 Stack Technique

- **Framework :** Next.js 15 (App Router)
- **Language :** TypeScript
- **Styling :** TailwindCSS
- **Icons :** Lucide React
- **Data :** JSON local (mock data)
- **Auth :** Mode démo (toggle Joueur/Recruteur)

### Pourquoi ces choix ?

- **Next.js :** SSR/SSG, routing file-based, optimisations auto
- **TypeScript :** Type safety, meilleure DX
- **TailwindCSS :** Utility-first, rapide, cohérent
- **Mode démo :** Permet de tester sans backend

---

## 🎯 Parcours Utilisateur

### Joueur
1. Arrive sur Landing → Comprend la valeur
2. Clique "Créer mon profil" → Formulaire
3. Rempli ses infos → Carte générée
4. Passe le test QI → Score affiché
5. Partage sa carte → Visibilité

### Recruteur
1. Arrive sur Landing → Clique "Explorer"
2. Liste joueurs → Applique filtres
3. Clique sur carte → Profil détaillé
4. Ajoute aux favoris → Contacte

---

## 🌍 Données Démo

12 joueurs fictifs réalistes de différents pays africains :
- Sénégal 🇸🇳
- Ghana 🇬🇭
- Nigeria 🇳🇬
- Mali 🇲🇱
- Côte d'Ivoire 🇨🇮
- Maroc 🇲🇦
- Guinée 🇬🇳

Tous les postes sont représentés : GK, CB, LB, RB, CDM, CM, CAM, LW, RW, ST, CF

---

## 📱 Responsive Design

- **Mobile-first approach**
- Breakpoints : sm (640px), md (768px), lg (1024px), xl (1280px)
- Navigation adaptative (burger menu mobile)
- Grilles flexibles (1 col mobile → 4 cols desktop)

---

## ✅ Checklist Qualité

### Performance
- [x] Images optimisées (placeholders en attendant uploads)
- [x] Lazy loading des composants
- [x] CSS minifié en production
- [x] Pas de dépendances inutiles

### Accessibilité
- [x] Contrastes WCAG AA
- [x] Navigation au clavier
- [x] Labels sur tous les inputs
- [x] Tailles de texte lisibles

### SEO
- [x] Metadata (title, description)
- [x] Structure HTML sémantique
- [x] URLs propres (/players/amadou-diallo)

### UX
- [x] États de chargement
- [x] Messages d'erreur clairs
- [x] Feedback visuel (hover, active)
- [x] Microcopy orienté utilisateur

---

## 🚧 Roadmap (Post-MVP)

### Phase 2
- [ ] Authentification réelle (Supabase Auth)
- [ ] Base de données Postgres
- [ ] Upload vidéo/photo réel (Cloudflare R2 / S3)
- [ ] Système de messagerie interne
- [ ] Notifications email

### Phase 3
- [ ] Paiement (Stripe) pour abonnements recruteurs
- [ ] Dashboard analytics (vues profil, clics, etc.)
- [ ] Système de badges/certifications
- [ ] API publique

---

## 🤝 Contribution

Ce projet est un MVP. Pour contribuer :
1. Fork le repo
2. Créer une branche (`feature/ma-fonctionnalite`)
3. Commit les changements
4. Push et créer une Pull Request

---

## 📄 Licence

© 2025 AfricaScoutPro. Tous droits réservés.

---

## 💬 Support

Pour toute question ou suggestion :
- Email : support@africascoutpro.com (placeholder)
- Twitter : @africascoutpro (placeholder)

---

**Conçu pour donner de l'espoir et des opportunités aux talents africains.** ⚽🌍
